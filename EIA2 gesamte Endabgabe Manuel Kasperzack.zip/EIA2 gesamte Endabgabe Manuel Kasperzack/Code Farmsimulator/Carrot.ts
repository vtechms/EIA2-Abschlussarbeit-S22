namespace FarmSimulator {
  export class Carrot extends Vegetable {
    constructor() {
      super("carrot", "#F2921D", 2, 2, 2);
    }
  }
}
