var FarmSimulator;
(function (FarmSimulator) {
    class Position {
        constructor(_column, _row) {
            this.column = _column;
            this.row = _row;
        }
    }
    FarmSimulator.Position = Position;
})(FarmSimulator || (FarmSimulator = {}));
//# sourceMappingURL=Position.js.map