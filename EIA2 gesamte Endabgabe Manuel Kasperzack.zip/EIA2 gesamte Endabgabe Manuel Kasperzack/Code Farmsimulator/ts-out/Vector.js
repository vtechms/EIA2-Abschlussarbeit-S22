var FarmSimulator;
(function (FarmSimulator) {
    class Vector {
        constructor(_x, _y) {
            this.x = _x;
            this.y = _y;
        }
    }
    FarmSimulator.Vector = Vector;
})(FarmSimulator || (FarmSimulator = {}));
//# sourceMappingURL=Vector.js.map