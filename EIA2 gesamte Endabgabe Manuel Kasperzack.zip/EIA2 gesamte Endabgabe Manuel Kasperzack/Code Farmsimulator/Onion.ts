namespace FarmSimulator {
  export class Onion extends Vegetable {
    constructor() {
      super("onion", "#F2F2F2", 4, 4, 4);
    }
  }
}
