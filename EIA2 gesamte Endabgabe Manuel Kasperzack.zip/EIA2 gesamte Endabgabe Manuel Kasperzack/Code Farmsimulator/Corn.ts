namespace FarmSimulator {
  export class Corn extends Vegetable {
    constructor() {
      super("corn", "#F2C029", 3, 3, 3);
    }
  }
}
