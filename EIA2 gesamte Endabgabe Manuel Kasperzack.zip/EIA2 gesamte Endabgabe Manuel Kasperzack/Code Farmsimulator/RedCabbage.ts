namespace FarmSimulator {
  export class RedCabbage extends Vegetable {
    constructor() {
      super("redCabbage", "#BF45AB", 5, 5, 5);
    }
  }
}
