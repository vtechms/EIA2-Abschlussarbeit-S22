namespace FarmSimulator {
  export class Tomato extends Vegetable {
    constructor() {
      super("tomato", "#F24130", 6, 6, 6);
    }
  }
}
